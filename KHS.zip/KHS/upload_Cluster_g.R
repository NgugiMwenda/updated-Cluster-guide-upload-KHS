library(tidyverse)
library(dplyr)
library(tidyr)

#clusterK <- read.delim("C:/Users/user/Desktop/DHS/pilot/rawF/clusterK.txt")
#structureK <- read.delim("C:/Users/user/Desktop/DHS/pilot/rawF/structureK.txt")
#householdK <- read.delim("C:/Users/user/Desktop/DHS/pilot/rawF/householdK.txt")

setwd('C:/Users/Prof/Desktop/kiroria official/Housing and Rent Survey R shinny Dashboard/clusterguidecode(1)/KHS')

cluster <- read.delim("cluster1a.tab")
cluster2 <- read.delim("cluster2a.tab")
structure <- read.delim("structure1a.tab")
household <- read.delim("household1a.tab")

#View(household)
View(cluster)
View(cluster2)
View(structure)
View(household)

cluster$interview__id<-cluster$cc
cluster2$interview__id<-cluster2$cc
structure$interview__id<-structure$cc
household$interview__id<-household$cc

clusterM<-cluster %>% group_by(clu02)%>%
  mutate(cluster__id = row_number())
clp<-clusterM %>% select(clu02,clu00)
clp1<-clp%>% 
  group_by(clu02) %>% 
  mutate(clu00_count = seq(n()) - 1) %>%
  pivot_wider(clu02, names_from =clu00_count, values_from = clu00, names_prefix = "clu00__")%>% as.data.frame()
#View(clp1)
#get the other data from the main cluster file
kk1<-clusterM %>% select(-clu00,-cluster__id) %>% 
  group_by(clu02,svn, cc, interview__id) %>%
  slice(1) %>% as.data.frame()
clp2<-kk1 %>% left_join(clp1, by="clu02")
##create responsible
clp2$'_responsible'<-c("Guid_Nak20")

write.table(clp2, file="cl4.tab", na = "",
            row.names = F, col.names = T,   quote = F,   sep = '\t')

###---------------------------------------------------------------------------clustering
str2<-structure %>% select(clu00,s02)
str3<-str2 %>% 
  group_by(clu00) %>% 
  mutate(s02_count = seq(n()) - 1) %>%
  pivot_wider(clu00, names_from =s02_count, values_from = s02, names_prefix = "s02__") %>%as.data.frame()

##excract cluster id from main file
clq<-clusterM %>% select(clu00, cluster__id)
str4<-str3 %>% left_join(clq, by="clu00")
#View(str4)
cou_clu<-cluster2 %>% select(-s02,-cc) %>% 
  group_by(clu00,chief,chieftelphone,asschief,asschieftelphone,interview__id) %>%
  slice(1) %>% as.data.frame()

str5<-str4 %>% left_join(cou_clu, by="clu00") %>% select(-clu02)
#View(str5)
write.table(str5, file="cluster.tab", na = "",
            row.names = F, col.names = T,   quote = F,   sep = '\t')


############33------------------------------------------------mwitu

d3<-str5 %>% 
  pivot_longer(cols = starts_with('s02'), values_to = 's02') %>%    
  group_by(interview__id, cluster__id) %>% 
  mutate(structure__id = row_number())

d4<-d3 %>% filter(!is.na(s02)) %>% select(-name)

d4$interview__id<-as.integer(d4$interview__id)

household1<-household %>% 
  group_by(clu00) %>% 
  mutate(h07 = row_number())

#add cluster id into the household tab
id_c<-clusterM %>% select(clu00, interview__id,cluster__id) 

household2<-household1 %>% left_join(id_c, by=c("clu00","interview__id")) %>% select(-clu02)

hh5<-household2 %>% left_join(d4, by=c("interview__id","s02","cluster__id")) #%>% arrange(interview__id, clusterpart__id,s02)

hh6<-hh5 %>% group_by(interview__id,structure__id) %>% mutate(household__id= row_number(structure__id))
hhf<-hh6 %>% select(interview__id,	cluster__id,	structure__id,	household__id,s02,h06b,h08, tel_h)
hhff<-hhf %>% select(-s02)
#View(hhff)
write.table(hhff, file="household.tab", na = "",
            row.names = F, col.names = T,   quote = F,   sep = '\t')
#-------------------------------end hh tab

hh55<-hh5 %>% select(interview__id, s02) %>%group_by(interview__id,s02)%>% summarise() %>%as.data.frame()
d44<-d4 %>% as.data.frame() %>% select(interview__id, s02) 
dz1<-d44 %>% anti_join(hh55, by=c("interview__id", "s02"))
dz2<-dz1 %>%left_join(d4, by=c("interview__id","s02"))
dz3<- merge(hh5,dz2,by=c("interview__id","cluster__id","structure__id","s02")) 
dz4<-dplyr::bind_rows(dz2, hh5)
################--------------------------------------------------------------------------------------------str


hhg<-dz4 %>% select(interview__id ,cluster__id,structure__id,s02, h06b,h07) 
str2<-hhg %>%
  mutate(h06b = h06b - 1) %>% 
  pivot_wider(names_from = h06b,values_from = h07,names_prefix = "h06b__")
#

str2K<-str2 %>% left_join(clusterM, by=c("interview__id", "cluster__id"))
##merge with some selected variables from str
str3<-structure %>% select(interview__id,s02,s01,gpc__Latitude,gpc__Longitude,clu00)

final.str<-str2K %>% left_join(str3, by=c("interview__id","s02","clu00"))

              
mins<-final.str %>% select(interview__id, cluster__id, structure__id,s02,
                           s01,gpc__Latitude,gpc__Longitude)
#head(mins)
#View(mins)

hhQ<-household %>% select(s02, h06b)
head(hhQ)
hhR<-hhQ %>% 
  group_by(s02) %>% 
  mutate(h06b_count = seq(n()) - 1) %>%
  pivot_wider(s02, names_from =h06b_count, values_from = h06b, names_prefix = "h06b__") %>%as.data.frame()
#View(hhR)
fFn<-mins %>% left_join(hhR, by="s02")

#-------------------------------------------------------xxxx

#str23<-str22 %>% rename(gps__Latitude=s04,gps__Longitude=s05,gps__Altitude=s06)%>%as.data.frame()
str24<- fFn[order(fFn$interview__id,fFn$cluster__id,fFn$structure__id,fFn$s02),]
#View(str24)
write.table(str24, file="structure.tab", na = "",
            row.names = F, col.names = T,   quote = F,   sep = '\t')

